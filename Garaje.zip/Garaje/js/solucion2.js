$(function(){
var planta;
var filas;
var columnas;
var plantageneral;
/*
   ------------
   | IndexedB |
   ------------
 */
Miplanta={piso:"",misplazas:new Array()};
miCentroComercial={};
miCentroComercial.indexedDB=window.indexedDB;
miCentroComercial.IDBKeyRange=window.IDBKeyRange;
miCentroComercial.IDBTransaction=window.IDTransaction;


$('#enviar').click(iniciar);

function iniciar(){
 //preguntar dimensión();
 //filas=document.getElementById("fila").value;
 //columnas=document.getElementById("columna").value;
 filas=$('#filas').val();
 alert(filas);
 columnas=2;
 alert(columnas);
 n_plantas=$('#plantas').val();
 alert(n_plantas);
 crearMiCentroComercial();
 dibujar_tablerohtml(filas, columnas);
 dibujar_tablerologico(n_plantas,filas,columnas);
 
 


}

function crearMiCentroComercial() {
     indexedDB.deleteDatabase("MiGarajeLuis");
    var bd_centroComercial = miCentroComercial.indexedDB.open("MiGarajeLuis", 1);

    //Comprobamos si existe para no sobrescribir
    bd_centroComercial.onupgradeneeded = function (e) {
        var conexion = e.currentTarget.result;
        var misplantas = conexion.createObjectStore("misplantas", {keyPath: "id", autoIncrement: true});
        misplantas.createIndex("por_piso", "piso", {unique: true});
        conexion.close();
    };
}

function anadirplanta(){
    plantageneral.id=1;
    var bd_centrocomercial=miCentroComercial.indexedDB.open("Migaraje");
    bd_centrocomercial.onsuccess=function(e){
        var conexion=bd_centrocomercial.result;
        var transaccion=conexion.transaction("misplazas","readwrite");
        var coches=transaccion.objectStore("misplazas");
        var guardar_coches=coches.put();
        conexion.close();
    }
}
/*
function actualizar_estado(){
    var bd_centrocomercial=miCentroComercial.indexedDB.open("Migaraje",7);
    var conexion=bd_centrocomercial.result;
    var transaction = conexion.transaction('misplazas', 'readwrite');
  var objectStore = transaction.objectStore('misplazas');

  objectStore.openCursor().onsuccess = function(event) {
    var cursor = event.target.result;
    if(cursor) {
      if(cursor.value==0) {
        var updateData = cursor.value;
          
        updateData.estado = 1;
        var request = cursor.update(updateData);
        request.onsuccess = function() {
          console.log('Plaza Cogida');
        };
      }else{
        var updateData = cursor.value;
        updateData.estado = 0;
        var request = cursor.update(updateData);
        request.onsuccess = function() {
          console.log('Plaza Liberada');
        };
    }
}
    objectStore.update(updateData);

}
}
*/
function dibujar_tablerohtml(html_filas,html_columnas){
    for(var ifilas=0;ifilas<html_filas;ifilas++){
        var elemento=document.createElement('p');
            for(var icolumnas=0;icolumnas<html_columnas;icolumnas++){
                var boton=document.createElement("button");
                boton.name="t_boton";
                boton.id=ifilas+""+icolumnas;
                boton.style.width="50px";
                boton.style.heigth="50px";
                boton.addEventListener("click",aparco);
                elemento.appendChild(boton);
            }
            document.getElementById("contenido").appendChild(elemento);
    }
}

function dibujar_tablerologico(totalplantas,logfilas,logcolumnas){
    alert(logcolumnas);
    planta=new Array(logfilas);
    for (var icolumnas=0;icolumnas<logfilas;icolumnas++){
        planta[icolumnas]=new Array(logcolumnas);
        planta[icolumnas].fill("0");
    }
        

    //guardar el objeto en IndexedDB
    
    guardaPlanta("1",planta);
    
    
}

function aparco(e){
    var nombreboton=e.currentTarget.id;
    var mifila=parseInt(nombreboton.split(" ")[0]);
    var micolumna=parseInt(nombreboton.split(" ")[1]);
    if(planta[mifila][micolumna]==0){
        planta[mifila][micolumna]=1;
    }else{
        alert("aparcamiento ocupado");
    }
    guardaPlanta("1",planta);
}

function guardaPlanta(IDBmipiso,IDBmidibujo) {
    Miplanta.piso=IDBmipiso;
    Miplanta.misplazas=IDBmidibujo;
    id=parseInt(IDBmipiso);
    Miplanta.id=id;
    var bd_centroComercial = miCentroComercial.indexedDB.open("MiGarajeLuis", 1);
    bd_centroComercial.onsuccess = function (e) {
        var conexion = bd_centroComercial.result;
        var transaccion = conexion.transaction("misplantas", "readwrite");
        var coches = transaccion.objectStore("misplantas");
        var guardar_coches = coches.put(Miplanta);
        conexion.close();
    };
}

})

